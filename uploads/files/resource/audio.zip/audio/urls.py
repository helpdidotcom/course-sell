from django.urls import path
from audio.views.home import home, download


urlpatterns = [
    path('', home, name='home'),
    path('download/<int:id>/<str:song_name>/', download, name='download')
]
