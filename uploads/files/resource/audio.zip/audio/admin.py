from django.contrib import admin
from audio.models.audio import Audio, Tag
from audio.models.category import Category

class TagAdmin(admin.TabularInline):
    model = Tag


class AudioAdmin(admin.ModelAdmin):
    inlines = [TagAdmin]


admin.site.register(Audio, AudioAdmin)
admin.site.register(Category)