from django import template

register = template.Library()

@register.filter
def sec_to_min(sec):
    return str(round((sec / 60))) + ' min'

@register.filter
def bytes_to_mb(bytes):
    return str(bytes // 1000000) + ' mb'


# def noneToImage(is_none):
#     if is_none == is_none:
#         return 