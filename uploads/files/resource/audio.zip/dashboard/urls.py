from django.urls import path
from dashboard.views.dashboard import dashboard, status, dash
from dashboard.views.upload import upload
from dashboard.views.category import category


urlpatterns = [
    path('', dashboard, name="dashboard"),
    path('upload/', upload, name='upload'),
    path('status/', status, name='status'),
    path('category/', category, name='category'),
    path('dash/', dash, name='dash'),
]
