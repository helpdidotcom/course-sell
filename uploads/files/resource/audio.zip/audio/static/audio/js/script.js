let backgroundNav = document.querySelector('.background-nav')
let siteContent = document.querySelector('.site-content')
let navTrigger = document.querySelector('.trigger-button')


navTrigger.addEventListener('click', function () {
    siteContent.classList.toggle('slide-left')
})
