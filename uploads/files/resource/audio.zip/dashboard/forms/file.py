from django import forms
from audio.models.audio import Audio

class AudioForm(forms.ModelForm):
    class Meta:
        model = Audio

        fields = ['file', 'category']

        widgets = {
            'file': forms.FileInput(attrs={'multiple': True})
        }