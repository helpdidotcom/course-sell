from django.shortcuts import render
from audio.models.category import Category



def category(request):
    categories = Category.objects.all()

    print(request.GET)
    
    return render(request, 'dashboard/category.html', {'categories': categories})