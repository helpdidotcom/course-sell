from django.db import models
from audio.models.category import Category


class Audio(models.Model):
    name = models.CharField(max_length=255, null=True)
    title = models.CharField(max_length=255, null=True)
    album = models.CharField(max_length=255, null=True)
    artist = models.CharField(max_length=255, null=True)
    file = models.FileField(upload_to='audio', null=True)
    cover = models.ImageField(upload_to='cover', null=True)
    status = models.BooleanField(default=False)
    size = models.IntegerField()
    duration = models.IntegerField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True)
    time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Tag(models.Model):
    desc = models.CharField(max_length=255, null=True)
    audio = models.ForeignKey(Audio, on_delete=models.CASCADE)
    


