from django.shortcuts import render
from audio.models.audio import Audio
from audio.models.category import Category

def home(request):
    categories = Category.objects.all()
    songs = Audio.objects.order_by('-time').all()[:50]

    return render(request, 'audio/home.html', {'featured_songs': songs})


def download(request, song_name, id):
    song = Audio.objects.get(id=id)

    
    return render(request, 'audio/download-page.html', {'song': song})