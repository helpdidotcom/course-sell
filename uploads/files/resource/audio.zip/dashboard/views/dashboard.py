from django.shortcuts import render


def dashboard(request):
    return render(request, 'dashboard/status.html')


def status(request):
    return render(request, 'dashboard/status.html')


def dash(request):
    return render(request, 'dashboard/temp.html')