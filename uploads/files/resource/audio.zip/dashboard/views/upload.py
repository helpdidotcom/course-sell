from django.shortcuts import redirect, render, HttpResponse
from django.core.files.storage import FileSystemStorage
from audio.models.category import Category
from avi.settings import BASE_DIR
from avi import settings
from audio.models.audio import Audio
from tinytag import TinyTag
import os
from dashboard.forms.file import AudioForm

from django.http import JsonResponse




def upload(request):
    if request.method == 'GET':
        form = AudioForm()
        return render(request, 'dashboard/file-upload.html', {'form': form})

    
    files = request.FILES.getlist('file')
    category = request.POST['category']
    for file in files:
        if (file.content_type != 'audio/mpeg'):
            return JsonResponse({'status': 'false'})
    
    
        tmp_folder = str(BASE_DIR) + str(settings.MEDIA_URL) + 'tmp'
        fs = FileSystemStorage()
        tmp_file = fs.save((tmp_folder + '/tmp'), file)
        save_file(tmp_file, file.name, file.size, category)
    
    return JsonResponse({'status': 'true'})



def save_file(file, file_name, file_size, category):
    audio_file = str(BASE_DIR) + str(settings.MEDIA_URL) + '/audio/' + file_name
    db_file = 'audio/' + file_name

    tag = TinyTag.get(file, image=True)
    
    artist = tag.artist
    album = tag.album
    composer = tag.composer
    genre = tag.genre
    duration = tag.duration
    title = tag.title
    year = tag.year
    cover = save_thumb((tag.get_image()), file_name)

    audio = Audio(name=file_name, title=title, album=album, artist=artist, size=file_size, duration=duration, file=db_file, cover=cover, category=Category(category))

    audio.save()
    os.rename(file, audio_file)



def save_thumb(image, name):
    cover_url = (f'{BASE_DIR}{settings.MEDIA_URL}/cover/{name}.jpg')
    cover = (f'cover/{name}.jpg')
    
    if (image == None):
        return ('None')
    
    with open(cover_url, "wb+") as binary_file: 
        binary_file.write(image)
    
    return cover